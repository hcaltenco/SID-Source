sigmund~ for Windows! 

INSTALL: Put both sigmund~.maxhelp and sigmund~.mxe in the search path.

All grats should go to Miller Puckette (for the pitch detection algo itself), and to Ron Mayer (for the FFT algo) - all I did was spend a couple of hours trying to figure out how to compile this beast.

Cheers,

Rob Clouth 2010

www.vaetxh.com