// SQTestDLL.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "windows.h"
#include <stdio.h>
#include "SQTestDLL.h"


// debug log file handle
FILE *gpDebugLogFile = NULL;


//==============================================================
// debug logging functions
//==============================================================

//------------------------------------------------------------------------------
// open debug log file
//------------------------------------------------------------------------------
SQRESULT SQ_debugLog_open (HSQUIRRELVM v)
{
	gpDebugLogFile = fopen("testScriptLOG.txt", "w");
	return SQ_OK;
}

SQ_BIND_GLOBAL_METHOD(debugLog_open);


//------------------------------------------------------------------------------
// close debug log file
//------------------------------------------------------------------------------
SQRESULT SQ_debugLog_close (HSQUIRRELVM v)
{
	if (gpDebugLogFile != NULL)
	{
		fclose(gpDebugLogFile);
	}

	return SQ_OK;
}

SQ_BIND_GLOBAL_METHOD(debugLog_close);


//------------------------------------------------------------------------------
// print a sting to the debug log file
//------------------------------------------------------------------------------
SQRESULT SQ_debugLog_print (HSQUIRRELVM v, const SQChar *pTxt)
{
	if (gpDebugLogFile != NULL)
	{
		wchar_t *inTxt = (wchar_t *)pTxt;
		fwprintf_s(gpDebugLogFile, inTxt);
	}

	return SQ_OK;
}

SQ_BIND_GLOBAL_METHOD(debugLog_print);


//------------------------------------------------------------------------------
// print an int to the debug log file
//------------------------------------------------------------------------------
SQRESULT SQ_debugLog_printInt (HSQUIRRELVM v, SQInteger val)
{
	if (gpDebugLogFile != NULL)
	{
		int inVal = (int)val;
		fprintf(gpDebugLogFile, "%d", inVal);
	}

	return SQ_OK;
}

SQ_BIND_GLOBAL_METHOD(debugLog_printInt);


//------------------------------------------------------------------------------
// print a float to the debug log file
//------------------------------------------------------------------------------
SQRESULT SQ_debugLog_printFloat (HSQUIRRELVM v, SQFloat val)
{
	if (gpDebugLogFile != NULL)
	{
		float inVal = (float)val;
		fprintf(gpDebugLogFile, "%f", inVal);
	}

	return SQ_OK;
}

SQ_BIND_GLOBAL_METHOD(debugLog_printFloat);


//------------------------------------------------------------------------------
// print a float vector to the debug log file
//------------------------------------------------------------------------------
SQRESULT SQ_debugLog_printVector (HSQUIRRELVM v, SQFloat valX, SQFloat valY, SQFloat valZ)
{
	if (gpDebugLogFile != NULL)
	{
		float inValX = (float)valX;
		float inValY = (float)valY;
		float inValZ = (float)valZ;
		fprintf(gpDebugLogFile, "%f, %f, %f", inValX, inValY, inValZ);
	}

	return SQ_OK;
}

SQ_BIND_GLOBAL_METHOD(debugLog_printVector);


//------------------------------------------------------------------------------
// add two integers and return the result (just a quick example of how to 
// return a value to a squirrel script
//------------------------------------------------------------------------------
SQRESULT SQ_testAddInts (HSQUIRRELVM v, SQInteger int1, SQInteger int2)
{
	SQInteger outInt = int1 + int2;

	sq_pushinteger(v, outInt);		// return the value to the squirrel script

	// return one return value pushed
	return 1;
}

SQ_BIND_GLOBAL_METHOD(testAddInts);
